package com.lms.www.leadmanagement.controller;

/** 
 * DEACTIVATED DUPLICATE SERVICE
 * This file was accidentally duplicated in the controller package and was causing 
 * ConflictingBeanDefinitionException. 
 */
public class LeadService {
    // Empty class to prevent conflict
}